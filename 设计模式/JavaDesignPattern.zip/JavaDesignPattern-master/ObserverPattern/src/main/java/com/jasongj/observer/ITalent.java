package com.jasongj.observer;

public interface ITalent {

  void newJob(String job);

}
