package com.jasongj.subject;

public interface ISubject {

  void action();

}
