package com.jasongj.transmission;

public abstract class Transmission{

  public abstract void gear();

}
