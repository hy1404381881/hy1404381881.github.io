package com.jasongj.singleton9;

public enum Singleton {

  INSTANCE;
  
  public void whatSoEverMethod() { }

}
