package com.jasongj.flyweight;

public interface FlyWeight {

  void action(String externalState);

}
