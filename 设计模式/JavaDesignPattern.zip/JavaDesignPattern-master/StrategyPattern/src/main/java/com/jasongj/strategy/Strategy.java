package com.jasongj.strategy;

public interface Strategy {

  void strategy(String input);

}
