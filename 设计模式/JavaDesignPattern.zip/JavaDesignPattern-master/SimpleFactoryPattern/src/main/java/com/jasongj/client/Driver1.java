package com.jasongj.client;

import com.jasongj.product.BenzCar;

public class Driver1 {

	public static void main(String[] args) {
		BenzCar car = new BenzCar();
		car.drive();
	}

}
