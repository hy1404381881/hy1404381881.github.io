-- ----------------------------
-- Records of users
-- ----------------------------

-- 插入数据，分别是 姓名（id）、年龄、身高体、重
INSERT INTO `users` VALUES ('1', 'Mac', '123');
INSERT INTO `users` VALUES ('2', 'Jack', '432');

